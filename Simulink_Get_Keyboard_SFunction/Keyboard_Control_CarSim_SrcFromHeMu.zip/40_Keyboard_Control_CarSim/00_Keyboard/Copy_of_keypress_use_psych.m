%============================================================================================
% The function can control the self-addition/substraction of two variables (speed and angle)
% Needs Psychtoolbox-3 Matlab Toolbox
% Later this file can be used for Matlab S function in Simulink
% Exit this program by pressing 'Esc'
%============================================================================================

%============================================================================================
% 2017-08-15 MH Created
%============================================================================================

%%
speed = 0;  % speed belongs to [-20 100]
angle = 0;  % angle belongs to [-180 180]

% The avaliable keys to press
KbName('UnifyKeyNames');
escapeKey = KbName('ESCAPE');
upKey = KbName('UpArrow');
downKey = KbName('DownArrow');
leftKey = KbName('LeftArrow');
rightKey = KbName('RightArrow');

% Loop the animation until the escape key is pressed
exitDemo = false;

while exitDemo == false

        % Check the keyboard to see if a button has been pressed
        [keyIsDown,secs, keyCode] = KbCheck;

        % Depending on the button press, either move ths position of the square
        % or exit the function
        % Exit=================================================================
        if keyCode(escapeKey)
            exitDemo = true;

        % Determining angle value of the vehicle; [-180 0] turning left, [0 180]
        % turning right.
        % Turning left=========================================================
        elseif keyCode(leftKey)
            angle = angle - 0.01
            if angle < -180
                angle = angle + 360
            end
            % Determin if up/down are pressed
            [~, ~, keyCode2nd] = KbCheck;
            
            % Left and forward
            if keyCode2nd(upKey)
                speed = speed + 0.01
                if speed > 100
                    speed = 100
                end
            % Left and backward
            elseif keyCode2nd(downKey)
                speed = speed - 0.05
                if speed < -20
                    speed = -20
                end
            % Left and no up/down    
            elseif  speed > 0
                speed = speed - 0.001
                    if speed <= 0.001
                     speed = 0
                    end
            elseif  speed < 0 
                speed = speed + 0.001
                if speed > -0.001
                    speed = 0
                end
            end    
        
        % Turning right=========================================================
        elseif keyCode(rightKey)
            angle = angle + 0.01
            if angle > 180
                angle = angle - 360
            end
            % Determin if up/down are pressed
            [~, ~, keyCode2nd] = KbCheck;
            
            % Right and forward
            if keyCode2nd(upKey)
                speed = speed + 0.01
                if speed > 100
                    speed = 100
                end
            % Right and backward
            elseif keyCode2nd(downKey)
                speed = speed - 0.05
                if speed < -20
                    speed = -20
                end
            % Left and no up/down    
            elseif  speed > 0
                speed = speed - 0.001
                    if speed <= 0.001
                     speed = 0
                    end
            elseif  speed < 0 
                speed = speed + 0.001
                if speed > -0.001
                    speed = 0
                end        
            end         

        % Determining speed value of the vehicle; Speed belongs [-20 100]. 
        % when downkey is pressed the speed descreases faster than "no-key" 
        %   case and can achieve to -20.
        % when upkey is pressed, the speed increases up to 100.
        % Acceleration=========================================================
        elseif keyCode(upKey)
            speed = speed + 0.01
            if speed > 100
                speed = 100
            end
            % Determin if right/left are pressed
            [~, ~, keyCode2nd] = KbCheck;

            if keyCode2nd(rightKey)
                angle = angle + 0.01
                if angle > 180
                    angle = angle - 360
                end
            elseif keyCode2nd(leftKey)
                angle = angle - 0.01
                if angle < -180
                    angle = angle + 360
                end
            end         

        % Break/Reverse========================================================
        elseif keyCode(downKey)
            speed = speed - 0.05
            if speed < -20
                speed = -20
            end
            % Determin if right/left are pressed
            [~, ~, keyCode2nd] = KbCheck;

            if keyCode2nd(rightKey)
                angle = angle + 0.01
                if angle > 180
                    angle = angle - 360
                end
            elseif keyCode2nd(leftKey)
                angle = angle - 0.01
                if angle < -180
                    angle = angle + 360
                end
            end 
        % No key===============================================================    
        % when no key is pressed, the speed descrease slowly to zero.         
        elseif ~keyIsDown && speed > 0
            speed = speed - 0.001
             if speed <= 0.001
                 speed = 0
             end
        elseif ~keyIsDown && speed < 0 
            if speed > -0.001
                speed = 0
            end
            speed = speed + 0.001
        end

end

