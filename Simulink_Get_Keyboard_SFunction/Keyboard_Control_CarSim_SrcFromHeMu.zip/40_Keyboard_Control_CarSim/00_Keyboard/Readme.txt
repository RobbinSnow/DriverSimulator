This folder contains files that detect keyboard events in Matlab environment. Three methods are implemented:

1) Need GUI feature: open a figure/GUI and the figure needs to be in focus.
	keypress_use_figure.m

2��Needs Psychtoolbox-3 Matlab Toolbox
	keypress_use_psych.m	
	key_ctr_MatlabS.m (Matlab S-Function)

3) Needs VS2012(MEX) + Simulink
	key_ctr_CMexS.c
	Keyboard_Control_CMexS.slx

