/*  file name : key_ctr_CMexS.c
%============================================================================================
% The CMex S function can control the self-addition/substraction of two variables (speed and angle)
% Used as Matlab S function in Simulink
 *  Actions:
 *      uparrow---------------forward
 *      downarrow-------------backward
 *      leftarrow-------------turning left
 *      rightarrow------------turning right
%============================================================================================

%============================================================================================
% 2017-08-17 MH Created
% 2017-08-20 MH Replaced kbhit()/getch() by GetAsyncKeyState();
%               Old UpdateSpeedAngle() was commented at the end
%============================================================================================
*/

#define S_FUNCTION_NAME key_ctr_CMexS
#define S_FUNCTION_LEVEL 2

#define     Reset       0x52    //Press r
#define     Left        0x25   //Press leftarrow
#define     Right       0x27   //Press rightarrow  
#define     Forward     0x26   //Press uparrow
#define     Backward    0x28   //Press downarrow


#include "simstruc.h"

#include <stdio.h>
#include <conio.h>

static void UpdateSpeedAngle(SimStruct *S, int_T tid);

/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 0);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return; /* Parameter mismatch will be reported by Simulink */
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 2);

    if (!ssSetNumInputPorts(S, 0)) return;
    
    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, 2);

    ssSetNumSampleTimes(S, 1);  /* Set number of sampling time */
    ssSetNumRWork(S, 0);    /* Set real work dimension */
    ssSetNumIWork(S, 0);    /* Set integer work dimension */
    ssSetNumPWork(S, 0);    /* Set pointer work dimension */
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);

    /* Take care when specifying exception free code - see sfuntmpl_doc.c */
    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    Specify the sample time as 1.0
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
//     ssSetSampleTime(S, 0, 1.0);
    ssSetSampleTime(S, 0, 0.1);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);      
}

#define MDL_INITIALIZE_CONDITIONS
/* Function: mdlInitializeConditions ========================================
 * Abstract:
 *    Initialize both discrete states to one.
 */
static void mdlInitializeConditions(SimStruct *S)
{
    real_T *x0 = ssGetRealDiscStates(S);
    int_T  lp;

    for (lp=0;lp<2;lp++) { 
        *x0++=1.0; 
    }
}



/* Function: mdlOutputs ================================================== */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    real_T            *y    = ssGetOutputPortRealSignal(S,0);
    real_T            *x    = ssGetRealDiscStates(S);
     
    y[0]=x[0];  /* Output x[0] i.e. speed */
    y[1]=x[1];  /* Output x[1] i.e. angle */
}



#define MDL_UPDATE
/* Function: mdlUpdate ==================================================*/
static void mdlUpdate(SimStruct *S, int_T tid)
{
    real_T            tempX[2] = {0.0, 0.0};
    real_T            *x       = ssGetRealDiscStates(S);
   
    UpdateSpeedAngle(S, tid);    
    printf("Speed is %f ; Angle is %f\n", x[0], x[1]);
}



/*==========================================================================================
% The function can control the self-addition/substraction of two variables (speed and angle)
% This function is forked from key_ctr_MatlabS.m in this folder
% Use GetAsyncKeyState() to read keyboard input; it reads the CAPTAL letter of keyboard
% i.e.A,B,C...
% ASCII code refers to Key_board_info.txt.
%==========================================================================================*/

static void UpdateSpeedAngle(SimStruct *S, int_T tid)
{
    real_T *x    = ssGetRealDiscStates(S);
    
    real_T speed = x[0];
    real_T angle = x[1];
    
    char key, key2nd;
    
    /* A key is pressed ============================================================== */
    if (GetAsyncKeyState(Reset)||GetAsyncKeyState(Left)||GetAsyncKeyState(Right)\
            ||GetAsyncKeyState(Forward)||GetAsyncKeyState(Backward))     
    {
        /* Determin operation modes based on keyboard input */
        if (GetAsyncKeyState(Reset))
        {
            key = Reset;
        }
        else if (GetAsyncKeyState(Left))
        {
            key = Left;
        }
        else if (GetAsyncKeyState(Right))
        {
            key = Right;
        }
        else if (GetAsyncKeyState(Forward))
        {
            key = Forward;
        }
        else if (GetAsyncKeyState(Backward))
        {
            key = Backward;
        }   
        
        /* Take actions based on keyboard entry */
        switch (key)
        {
            case Reset:  /* Reset is pressed */
                speed = 0;
                angle = 0;
                break;
            /* Determining angle value of the vehicle; [-180 0] turning left, [0 180] turning right. */
            /* Turning left ========================================================= */
            case Left:  /* leftarrow is pressed */
                angle = angle - 0.01;
                if (angle < -180)
                {
                    angle = angle + 360;
                }
                /* Left and forward */
                if (GetAsyncKeyState(Forward)) /* uparrow is pressed */
                {
                    speed = speed + 0.01;
                    if (speed > 100)
                    {
                        speed = 100;
                    }
                }
                /* Left and backward */
                else if (GetAsyncKeyState(Backward)) /* downarrow is pressed */
                {
                    speed = speed - 0.05;
                    if (speed < -20)
                    {
                        speed = -20;
                    }                            
                }
                /* Left and no up/down */
                else if (speed > 0)
                {
                    speed = speed - 0.001;
                    if (speed <= 0.001)
                    {
                        speed = 0; 
                    }
                }
                else if  (speed < 0)
                {
                    speed = speed + 0.001;
                    if (speed > -0.001)
                    {
                        speed = 0;
                    } 
                }
                break;
            /* Turning right ========================================================= */
            case Right: /* rightarrow is pressed */
                angle = angle + 0.01;
                if (angle > 180)
                {
                    angle = angle - 360;
                }
                /* Determin if up/down is pressed */
                /* Right and forward */
                if (GetAsyncKeyState(Forward)) /* uparrow is pressed */
                {
                    speed = speed + 0.01;
                    if (speed > 100)
                    {
                        speed = 100;
                    }
                }
                /* Left and backward */
                else if (GetAsyncKeyState(Backward)) /* downarrow is pressed */
                {
                    speed = speed - 0.05;
                    if (speed < -20)
                    {
                        speed = -20;
                    }                            
                }
                /* Left and no up/down */
                else if (speed > 0)
                {
                    speed = speed - 0.001;
                    if (speed <= 0.001)
                    {
                        speed = 0; 
                    }
                }
                else if  (speed < 0)
                {
                    speed = speed + 0.001;
                    if (speed > -0.001)
                    {
                        speed = 0;
                    } 
                } 
                break;
            /*% Determining speed value of the vehicle; Speed belongs [-20 100]. 
            % when downkey is pressed the speed descreases faster than "no-key" 
            %   case and can achieve to -20.
            % when upkey is pressed, the speed increases up to 100.
            % Acceleration========================================================= */
            case Forward: /* uparrow is pressed */
                speed = speed + 0.01;
                if (speed > 100)
                {
                    speed = 100;
                }
                /* Determin if right/left is pressed */
                /* Right and forward */
                if (GetAsyncKeyState(Right)) /* rightarrow is pressed */
                {
                    angle = angle + 0.01;
                    if (angle > 180)
                    {
                        angle = angle - 360;
                    }
                }
                /* Left and forward */
                else if (GetAsyncKeyState(Left)) /* leftarrow is pressed */
                {
                    angle = angle - 0.01;
                    if (angle < -180)
                    {
                        angle = angle + 360;
                    }
                }                
                break;
            /* Deceleration/backward=============================================== */
            case Backward:  /* downarrow is pressed */
                speed = speed - 0.05;
                if (speed < -20)
                {
                    speed = -20;
                }
                /* Determin if right/left is pressed */
                    /* Right and forward */
                if (GetAsyncKeyState(Right)) /* rightarrow is pressed */
                {
                    angle = angle + 0.01;
                    if (angle > 180)
                    {
                        angle = angle - 360;
                    }
                }
                /* Left and forward */
                else if (GetAsyncKeyState(Left)) /* leftarrow is pressed */
                {
                    angle = angle - 0.01;
                    if (angle < -180)
                    {
                        angle = angle + 360;
                    }
                } 
                break;
        }   
    }
    /* No key is pressed ============================================================== 
       when no key is pressed, the speed descrease slowly to zero. */    
    else if (!GetAsyncKeyState(Reset) && !GetAsyncKeyState(Left) && !GetAsyncKeyState(Right)\
            && !GetAsyncKeyState(Forward) && !GetAsyncKeyState(Backward) && speed > 0)
    {   printf("no key is pressed\n");
        speed = speed - 0.001;
         if (speed <= 0.001)
         {
            speed = 0;
         }
    }
    else if (!GetAsyncKeyState(Reset)&&!GetAsyncKeyState(Left)&&!GetAsyncKeyState(Right)\
            &&!GetAsyncKeyState(Forward)&&!GetAsyncKeyState(Backward) && speed < 0)
    {
     speed = speed + 0.001;
     if (speed > -0.001)
     {
        speed = 0;
     }     
    }
    x[0] = speed;
    x[1] = angle;
}
    


/* Function: mdlTerminate =====================================================
 * Abstract:
 *    No termination needed, but we are required to have this routine.
 */
static void mdlTerminate(SimStruct *S)
{
    UNUSED_ARG(S); /* unused input argument */
}

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif



/*=========================================================================*/
// 
// static void UpdateSpeedAngle_OLD(SimStruct *S, int_T tid)
// {
//     real_T *x    = ssGetRealDiscStates(S);
//     
//     real_T speed = x[0];
//     real_T angle = x[1];
//     
//     char key, key2nd;
//     
//     /* A key is pressed ============================================================== */
//     if (kbhit())   
//     {
//         printf("A key is pressed\n");
//         key = getch();
//         printf("A key is pressed\n");
//         switch (key)
//         {
//             case Reset:  /* Reset is pressed */
//                 speed = 0;
//                 angle = 0;
//                 break;
//             /* Determining angle value of the vehicle; [-180 0] turning left, [0 180] turning right. */
//             /* Turning left ========================================================= */
//             case Left:  /* leftarrow is pressed */
//                 angle = angle - 0.01;
//                 if (angle < -180)
//                 {
//                     angle = angle + 360;
//                 }
//                 /* Determin if up/down is pressed */  
//                 if (kbhit())
//                 {
//                     key2nd = getch();
//                     /* Left and forward */
//                     if (key2nd == Forward) /* uparrow is pressed */
//                     {
//                         speed = speed + 0.01;
//                         if (speed > 100)
//                         {
//                             speed = 100;
//                         }
//                     }
//                     /* Left and backward */
//                     else if (key2nd == Backward) /* downarrow is pressed */
//                     {
//                         speed = speed - 0.05;
//                         if (speed < -20)
//                         {
//                             speed = -20;
//                         }                            
//                     }
//                 /* Left and no up/down */
//                 else if (speed > 0)
//                 {
//                     speed = speed - 0.001;
//                     if (speed <= 0.001)
//                     {
//                         speed = 0; 
//                     }
//                 }
//                 else if  (speed < 0)
//                 {
//                     speed = speed + 0.001;
//                     if (speed > -0.001)
//                     {
//                         speed = 0;
//                     } 
//                 }
//                 }
//                 break;
//             /* Turning right ========================================================= */
//             case Right: /* rightarrow is pressed */
//                 angle = angle + 0.01;
//                 if (angle > 180)
//                 {
//                     angle = angle - 360;
//                 }
//             /* Determin if up/down is pressed */
//                 if (kbhit())
//                 {
//                     key2nd = getch();
//                     /* Right and forward */
//                     if (key2nd == Forward) /* uparrow is pressed */
//                     {
//                         speed = speed + 0.01;
//                         if (speed > 100)
//                         {
//                             speed = 100;
//                         }
//                     }
//                     /* Left and backward */
//                     else if (key2nd == Backward) /* downarrow is pressed */
//                     {
//                         speed = speed - 0.05;
//                         if (speed < -20)
//                         {
//                             speed = -20;
//                         }                            
//                     }
//                 /* Left and no up/down */
//                 else if (speed > 0)
//                 {
//                     speed = speed - 0.001;
//                     if (speed <= 0.001)
//                     {
//                         speed = 0; 
//                     }
//                 }
//                 else if  (speed < 0)
//                 {
//                     speed = speed + 0.001;
//                     if (speed > -0.001)
//                     {
//                         speed = 0;
//                     } 
//                 } 
//                 }
//                 break;
//             /*% Determining speed value of the vehicle; Speed belongs [-20 100]. 
//             % when downkey is pressed the speed descreases faster than "no-key" 
//             %   case and can achieve to -20.
//             % when upkey is pressed, the speed increases up to 100.
//             % Acceleration========================================================= */
//             case Forward: /* uparrow is pressed */
//                 speed = speed + 0.01;
//                 if (speed > 100)
//                 {
//                     speed = 100;
//                 }
//                 /* Determin if right/left is pressed */
//                 if (kbhit())
//                 {
//                     key2nd = getch();
//                     /* Right and forward */
//                     if (key2nd == Right) /* rightarrow is pressed */
//                     {
//                         angle = angle + 0.01;
//                         if (angle > 180)
//                         {
//                             angle = angle - 360;
//                         }
//                     }
//                     /* Left and forward */
//                     else if (key2nd == Left) /* leftarrow is pressed */
//                     {
//                         angle = angle - 0.01;
//                         if (angle < -180)
//                         {
//                             angle = angle + 360;
//                         }
//                     }                
//                 }
//                 break;
//             /* Deceleration/backward=============================================== */
//             case Backward:  /* downarrow is pressed */
//                 speed = speed - 0.05;
//                 if (speed < -20)
//                 {
//                     speed = -20;
//                 }
//                 /* Determin if right/left is pressed */
//                 if (kbhit())
//                 {
//                     key2nd = getch();
//                     /* Right and forward */
//                     if (key2nd == Right) /* rightarrow is pressed */
//                     {
//                         angle = angle + 0.01;
//                         if (angle > 180)
//                         {
//                             angle = angle - 360;
//                         }
//                     }
//                     /* Left and forward */
//                     else if (key2nd == Left) /* leftarrow is pressed */
//                     {
//                         angle = angle - 0.01;
//                         if (angle < -180)
//                         {
//                             angle = angle + 360;
//                         }
//                     } 
//                 }
//                 break;
//             default: printf("Other keys\n");
//         }   
//     }
//     /* No key is pressed ============================================================== 
//        when no key is pressed, the speed descrease slowly to zero. */
//     
//     else if (!kbhit() && speed > 0)
//     {   printf("no key is pressed\n");
//         speed = speed - 0.001;
//          if (speed <= 0.001)
//          {
//             speed = 0;
//          }
//     }
//     else if (!kbhit() && speed < 0)
//     {
//      speed = speed + 0.001;
//      if (speed > -0.001)
//      {
//         speed = 0;
//      }     
//     }
//     x[0] = speed;
//     x[1] = angle;
// }

