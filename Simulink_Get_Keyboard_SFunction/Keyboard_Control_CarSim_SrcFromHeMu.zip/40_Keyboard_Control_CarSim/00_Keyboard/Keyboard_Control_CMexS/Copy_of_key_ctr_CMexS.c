/*  File    : dsfunc.c
 *  Abstract:
 *
 *      Example C-file S-function for defining a discrete system.  
 *
 *      x(n+1) = Ax(n) + Bu(n)
 *      y(n)   = Cx(n) + Du(n)
 *
 *      For more details about S-functions, see simulink/src/sfuntmpl_doc.c.
 * 
 *  Copyright 1990-2009 The MathWorks, Inc.
 *  $Revision: 1.1.6.1 $
 */

#define S_FUNCTION_NAME key_ctr_CMexS
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"

#include <stdio.h>
#include <conio.h>

// #define U(element) (*uPtrs[element])  /* Pointer to Input Port0 */

static real_T A[2][2]={ { -1.3839, -0.5097 } ,
                        {  1     ,  0      }
                      };
 
static real_T B[2][2]={ { -2.5559,  0      } ,
                        {  0     ,  4.2382 }
                      };
 
static real_T C[2][2]={ {  0     ,  2.0761 } ,
                        {  0     ,  7.7891 }
                      };
 
static real_T D[2][2]={ { -0.8141, -2.9334 } ,
                        {  1.2426,  0      }
                      };
 

/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 0);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return; /* Parameter mismatch will be reported by Simulink */
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 2);

    if (!ssSetNumInputPorts(S, 0)) return;
    
    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, 2);

    ssSetNumSampleTimes(S, 1);  /* Set number of sampling time */
    ssSetNumRWork(S, 0);    /* Set real work dimension */
    ssSetNumIWork(S, 0);    /* Set integer work dimension */
    ssSetNumPWork(S, 0);    /* Set pointer work dimension */
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);

    /* Take care when specifying exception free code - see sfuntmpl_doc.c */
    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    Specify the sample time as 1.0
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, 1.0);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);      
}

#define MDL_INITIALIZE_CONDITIONS
/* Function: mdlInitializeConditions ========================================
 * Abstract:
 *    Initialize both discrete states to one.
 */
static void mdlInitializeConditions(SimStruct *S)
{
    real_T *x0 = ssGetRealDiscStates(S);
    int_T  lp;

    for (lp=0;lp<2;lp++) { 
        *x0++=1.0; 
    }
}



/* Function: mdlOutputs =======================================================
 * Abstract:
 *      y = Cx + Du 
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    real_T            *y    = ssGetOutputPortRealSignal(S,0);
    real_T            *x    = ssGetRealDiscStates(S);
 
    UNUSED_ARG(tid); /* not used in single tasking mode */

    /* y=Cx+Du */
    
//     y[0]=C[0][0]*x[0]+C[0][1]*x[1];
//     y[1]=C[1][0]*x[0]+C[1][1]*x[1];
    
    y[0]=x[0];  /* Output x[0] i.e. speed */
    y[1]=x[1];  /* Output x[1] i.e. angle */
}



#define MDL_UPDATE
/* Function: mdlUpdate ======================================================
 * Abstract:
 *      xdot = Ax + Bu
 */
static void mdlUpdate(SimStruct *S, int_T tid)
{
    real_T            tempX[2] = {0.0, 0.0};
    real_T            *x       = ssGetRealDiscStates(S);

    UNUSED_ARG(tid); /* not used in single tasking mode */

    /* xdot=Ax+Bu */
    
//     tempX[0]=A[0][0]*x[0]+A[0][1]*x[1];
//     tempX[1]=A[1][0]*x[0]+A[1][1]*x[1];
//  
//     x[0]=tempX[0];
//     x[1]=tempX[1];
    
//     real_T speed = x[0];
//     real_T angle = x[1];
//     [speed, angle] = UpdateSpeedAngle(speed, angle);
//     UpdateSpeedAngle(SimStruct *S, int_T tid);
//     UpdateSpeedAngle(*S, tid);
    UpdateSpeedAngle(S, tid);    
    
    printf("Speed is %f ; Angle is %f", x[0], x[1]);
    printf("\n");
}



/*==========================================================================================
% The function can control the self-addition/substraction of two variables (speed and angle)
% This function is forked from key_ctr_MatlabS.m in this folder
%==========================================================================================*/

static void UpdateSpeedAngle(SimStruct *S, int_T tid)
{
    real_T *x    = ssGetRealDiscStates(S);
    
    real_T speed = x[0];
    real_T angle = x[1];
    
    char key, key2nd;
    
    /* A key is pressed ============================================================== */
    if (kbhit())
    {
        key = getch();
        switch (key)
        {
            case 0x82:  /* Reset is pressed */
                speed = 0;
                angle = 0;
            /* Determining angle value of the vehicle; [-180 0] turning left, [0 180] turning right. */
            /* Turning left ========================================================= */
            case 0x25:  /* leftarrow is pressed */
                angle = angle - 0.01;
                if (angle < -180)
                {
                    angle = angle + 360;
                }
                /* Determin if up/down are pressed */  
                if (kbhit())
                {
                    key2nd = getch();
                    /* Left and forward */
                    if (key2nd == 0x26) /* uparrow is pressed */
                    {
                        speed = speed + 0.01;
                        if (speed > 100)
                        {
                            speed = 100;
                        }
                    }
                    /* Left and backward */
                    else if (key2nd == 0x28) /* downarrow is pressed */
                    {
                        speed = speed - 0.05;
                        if (speed < -20)
                        {
                            speed = -20;
                        }                            
                    }
                /* Left and no up/down */
                else if (speed > 0)
                {
                    speed = speed - 0.001;
                    if (speed <= 0.001)
                    {
                        speed = 0; 
                    }
                }
                else if  (speed < 0)
                {
                    speed = speed + 0.001;
                    if (speed > -0.001)
                    {
                        speed = 0;
                    } 
                }
                }
            /* Turning right ========================================================= */
            case 0x27: /* rightarrow is pressed */
                angle = angle + 0.01;
                if (angle > 180)
                {
                    angle = angle - 360;
                }
            /* Determin if up/down is pressed */
                if (kbhit())
                {
                    key2nd = getch();
                    /* Right and forward */
                    if (key2nd == 0x26) /* uparrow is pressed */
                    {
                        speed = speed + 0.01;
                        if (speed > 100)
                        {
                            speed = 100;
                        }
                    }
                    /* Left and backward */
                    else if (key2nd == 0x28) /* downarrow is pressed */
                    {
                        speed = speed - 0.05;
                        if (speed < -20)
                        {
                            speed = -20;
                        }                            
                    }
                /* Left and no up/down */
                else if (speed > 0)
                {
                    speed = speed - 0.001;
                    if (speed <= 0.001)
                    {
                        speed = 0; 
                    }
                }
                else if  (speed < 0)
                {
                    speed = speed + 0.001;
                    if (speed > -0.001)
                    {
                        speed = 0;
                    } 
                } 
                }
            /*% Determining speed value of the vehicle; Speed belongs [-20 100]. 
            % when downkey is pressed the speed descreases faster than "no-key" 
            %   case and can achieve to -20.
            % when upkey is pressed, the speed increases up to 100.
            % Acceleration========================================================= */
            case 0x26: /* uparrow is pressed */
                speed = speed + 0.01;
                if (speed > 100)
                {
                    speed = 100;
                }
                /* Determin if right/left is pressed */
                if (kbhit())
                {
                    key2nd = getch();
                    /* Right and forward */
                    if (key2nd == 0x27) /* rightarrow is pressed */
                    {
                        angle = angle + 0.01;
                        if (angle > 180)
                        {
                            angle = angle - 360;
                        }
                    }
                    /* Left and forward */
                    else if (key2nd == 0x25) /* leftarrow is pressed */
                    {
                        angle = angle - 0.01;
                        if (angle < -180)
                        {
                            angle = angle + 360;
                        }
                    }                
                }
            /* Deceleration/backward=============================================== */
            case 0x28:  /* downarrow is pressed */
                speed = speed - 0.05;
                if (speed < -20)
                {
                    speed = -20;
                }
                /* Determin if right/left is pressed */
                if (kbhit())
                {
                    key2nd = getch();
                    /* Right and forward */
                    if (key2nd == 0x27) /* rightarrow is pressed */
                    {
                        angle = angle + 0.01;
                        if (angle > 180)
                        {
                            angle = angle - 360;
                        }
                    }
                    /* Left and forward */
                    else if (key2nd == 0x25) /* leftarrow is pressed */
                    {
                        angle = angle - 0.01;
                        if (angle < -180)
                        {
                            angle = angle + 360;
                        }
                    } 
                }               
        }   
    }
    /* No key is pressed ============================================================== 
       when no key is pressed, the speed descrease slowly to zero. */
    else if (!kbhit() && speed > 0)
    {
        speed = speed - 0.001;
         if (speed <= 0.001)
         {
            speed = 0;
         }
    }
    else if (!kbhit() && speed < 0)
    {
     speed = speed + 0.001;
     if (speed > -0.001)
     {
        speed = 0;
     }     
    }
    x[0] = speed;
    x[1] = angle;
}
    


/* Function: mdlTerminate =====================================================
 * Abstract:
 *    No termination needed, but we are required to have this routine.
 */
static void mdlTerminate(SimStruct *S)
{
    UNUSED_ARG(S); /* unused input argument */
}

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
