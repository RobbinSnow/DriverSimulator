%============================================================================================
% The function can control the self-addition/substraction of two variables (speed and angle)
% Needs to open a figure/GUI and the figure needs to be in focus which is not good
% Later this function may be used for Matlab S function in Simulink
% Exit the function by closing the figure
%============================================================================================

%============================================================================================
% 2017-08-11 MH Created
%============================================================================================
function keypress_use_figure
clc
close all
clear all
%%
angle = 0;
speed = 0;
button_pressed = '';

fig = figure;
figure('visible','off');
plot(1)

% set(fig,'windowkeyreleasefcn',@keyreleasefcn);
% 
%     function keyreleasefcn(fig,evt)
%         evt.Key
%     end

    set(fig,'windowkeypressfcn',@keypressfcn);
    function keypressfcn(h,evt)
        button_pressed = evt.Key;
        
               
        if strcmp(button_pressed, 'leftarrow')
            angle = angle - 0.01
                if angle < -180
                    angle = angle + 360
                end
        elseif strcmp(button_pressed, 'rightarrow')
            angle = angle + 0.01
                if angle > 180
                    angle = angle - 360
                end

        % Determining speed value of the vehicle; Speed belongs [-20 100]. 
        % when no key is pressed, the speed descrease slowly to zero. 
        % when downkey is pressed the speed descreases faster than "no-key" 
        %   case and can achieve to -20.
        % when upkey is pressed, the speed increases up to 100.

        elseif strcmp(button_pressed, 'uparrow')
            speed = speed + 0.01
                if speed > 100
                    speed = 100
                end
        elseif strcmp(button_pressed, 'downarrow')
            speed = speed - 0.1
                if speed < -20
                    speed = -20
                end
        else
            while (speed >= 0)
                speed = speed - 0.001
            end

            while (speed < 0)
                speed = speed + 0.001
            end
        end
        
        
    end 

end