function [sys,x0,str,ts,simStateCompliance] = key_ctr_MatlabS(t,x,u,flag)
%SFUNTMPL General MATLAB S-Function Template
%   With MATLAB S-functions, you can define you own ordinary differential
%   equations (ODEs), discrete system equations, and/or just about
%   any type of algorithm to be used within a Simulink block diagram.
%
%   The general form of an MATLAB S-function syntax is:
%       [SYS,X0,STR,TS,SIMSTATECOMPLIANCE] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   What is returned by SFUNC at a given point in time, T, depends on the
%   value of the FLAG, the current state vector, X, and the current
%   input vector, U.
%
%   FLAG   RESULT             DESCRIPTION
%   -----  ------             --------------------------------------------
%   0      [SIZES,X0,STR,TS]  Initialization, return system sizes in SYS,
%                             initial state in X0, state ordering strings
%                             in STR, and sample times in TS.
%   1      DX                 Return continuous state derivatives in SYS.
%   2      DS                 Update discrete states SYS = X(n+1)
%   3      Y                  Return outputs in SYS.
%   4      TNEXT              Return next time hit for variable step sample
%                             time in SYS.
%   5                         Reserved for future (root finding).
%   9      []                 Termination, perform any cleanup SYS=[].
%
%
%   The state vectors, X and X0 consists of continuous states followed
%   by discrete states.
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%   When SFUNC is called with FLAG = 0, the following information
%   should be returned:
%
%      SYS(1) = Number of continuous states.
%      SYS(2) = Number of discrete states.
%      SYS(3) = Number of outputs.
%      SYS(4) = Number of inputs.
%               Any of the first four elements in SYS can be specified
%               as -1 indicating that they are dynamically sized. The
%               actual length for all other flags will be equal to the
%               length of the input, U.
%      SYS(5) = Reserved for root finding. Must be zero.
%      SYS(6) = Direct feedthrough flag (1=yes, 0=no). The s-function
%               has direct feedthrough if U is used during the FLAG=3
%               call. Setting this to 0 is akin to making a promise that
%               U will not be used during FLAG=3. If you break the promise
%               then unpredictable results will occur.
%      SYS(7) = Number of sample times. This is the number of rows in TS.
%
%
%      X0     = Initial state conditions or [] if no states.
%
%      STR    = State ordering strings which is generally specified as [].
%
%      TS     = An m-by-2 matrix containing the sample time
%               (period, offset) information. Where m = number of sample
%               times. The ordering of the sample times must be:
%
%               TS = [0      0,      : Continuous sample time.
%                     0      1,      : Continuous, but fixed in minor step
%                                      sample time.
%                     PERIOD OFFSET, : Discrete sample time where
%                                      PERIOD > 0 & OFFSET < PERIOD.
%                     -2     0];     : Variable step discrete sample time
%                                      where FLAG=4 is used to get time of
%                                      next hit.
%
%               There can be more than one sample time providing
%               they are ordered such that they are monotonically
%               increasing. Only the needed sample times should be
%               specified in TS. When specifying more than one
%               sample time, you must check for sample hits explicitly by
%               seeing if
%                  abs(round((T-OFFSET)/PERIOD) - (T-OFFSET)/PERIOD)
%               is within a specified tolerance, generally 1e-8. This
%               tolerance is dependent upon your model's sampling times
%               and simulation time.
%
%               You can also specify that the sample time of the S-function
%               is inherited from the driving block. For functions which
%               change during minor steps, this is done by
%               specifying SYS(7) = 1 and TS = [-1 0]. For functions which
%               are held during minor steps, this is done by specifying
%               SYS(7) = 1 and TS = [-1 1].
%
%      SIMSTATECOMPLIANCE = Specifices how to handle this block when saving and
%                           restoring the complete simulation state of the
%                           model. The allowed values are: 'DefaultSimState',
%                           'HasNoSimState' or 'DisallowSimState'. If this value
%                           is not speficified, then the block's compliance with
%                           simState feature is set to 'UknownSimState'.


%   Copyright 1990-2010 The MathWorks, Inc.
%   $Revision: 1.18.2.5 $

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 2;
sizes.NumOutputs     = 0;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [0 0];

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)

sys = [];

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

[speed, angle] = UpdateSpeedAngle(t,x)

sys = [speed angle];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

% sys = [x(1) x(2)];
sys = [];

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate


%==========================================================================================
% The function can control the self-addition/substraction of two variables (speed and angle)
% Needs Psychtoolbox-3 Matlab Toolbox
% This function is forked from keypress_use_psych.m in this folder
%==========================================================================================
function [speed, angle] = UpdateSpeedAngle(t,x)
    
    speed = x(1);
    angle = x(2);
    % The avaliable keys to press
    KbName('UnifyKeyNames');
    escapeKey = KbName('ESCAPE');
    upKey = KbName('UpArrow');
    downKey = KbName('DownArrow');
    leftKey = KbName('LeftArrow');
    rightKey = KbName('RightArrow');
    rKey = KbName('r');

    % Loop the animation until the escape key is pressed
    exitDemo = false;

%     while exitDemo == false

        % Check the keyboard to see if a button has been pressed
        [keyIsDown,secs, keyCode] = KbCheck;

        % Depending on the button press, either move ths position of the square
        % or exit the function
        % Exit=================================================================
        if keyCode(escapeKey)
            exitDemo = true;
            
        % Reset================================================================    
        elseif keyCode(rKey)
            speed = 0
            angle = 0
            
        % Determining angle value of the vehicle; [-180 0] turning left, [0 180]
        % turning right.
        % Turning left=========================================================
        elseif keyCode(leftKey)
            angle = angle - 0.01
            if angle < -180
                angle = angle + 360
            end
            % Determin if up/down are pressed
            [~, ~, keyCode2nd] = KbCheck;
            
            % Left and forward
            if keyCode2nd(upKey)
                speed = speed + 0.01
                if speed > 100
                    speed = 100
                end
            % Left and backward
            elseif keyCode2nd(downKey)
                speed = speed - 0.05
                if speed < -20
                    speed = -20
                end
            % Left and no up/down    
            elseif  speed > 0
                speed = speed - 0.001
                    if speed <= 0.001
                     speed = 0
                    end
            elseif  speed < 0 
                speed = speed + 0.001
                if speed > -0.001
                    speed = 0
                end
            end    
        
        % Turning right=========================================================
        elseif keyCode(rightKey)
            angle = angle + 0.01
            if angle > 180
                angle = angle - 360
            end
            % Determin if up/down are pressed
            [~, ~, keyCode2nd] = KbCheck;
            
            % Right and forward
            if keyCode2nd(upKey)
                speed = speed + 0.01
                if speed > 100
                    speed = 100
                end
            % Right and backward
            elseif keyCode2nd(downKey)
                speed = speed - 0.05
                if speed < -20
                    speed = -20
                end
            % Left and no up/down    
            elseif  speed > 0
                speed = speed - 0.001
                    if speed <= 0.001
                     speed = 0
                    end
            elseif  speed < 0 
                speed = speed + 0.001
                if speed > -0.001
                    speed = 0
                end        
            end         

        % Determining speed value of the vehicle; Speed belongs [-20 100]. 
        % when downkey is pressed the speed descreases faster than "no-key" 
        %   case and can achieve to -20.
        % when upkey is pressed, the speed increases up to 100.
        % Acceleration=========================================================
        elseif keyCode(upKey)
            speed = speed + 0.01
            if speed > 100
                speed = 100
            end
            % Determin if right/left are pressed
            [~, ~, keyCode2nd] = KbCheck;

            if keyCode2nd(rightKey)
                angle = angle + 0.01
                if angle > 180
                    angle = angle - 360
                end
            elseif keyCode2nd(leftKey)
                angle = angle - 0.01
                if angle < -180
                    angle = angle + 360
                end
            end         

        % Break/Reverse========================================================
        elseif keyCode(downKey)
            speed = speed - 0.05
            if speed < -20
                speed = -20
            end
            % Determin if right/left are pressed
            [~, ~, keyCode2nd] = KbCheck;

            if keyCode2nd(rightKey)
                angle = angle + 0.01
                if angle > 180
                    angle = angle - 360
                end
            elseif keyCode2nd(leftKey)
                angle = angle - 0.01
                if angle < -180
                    angle = angle + 360
                end
            end 
        % No key===============================================================    
        % when no key is pressed, the speed descrease slowly to zero.         
        elseif ~keyIsDown && speed > 0
            speed = speed - 0.001
             if speed <= 0.001
                 speed = 0
             end
        elseif ~keyIsDown && speed < 0 
            if speed > -0.001
                speed = 0
            end
            speed = speed + 0.001
        end
%     end

