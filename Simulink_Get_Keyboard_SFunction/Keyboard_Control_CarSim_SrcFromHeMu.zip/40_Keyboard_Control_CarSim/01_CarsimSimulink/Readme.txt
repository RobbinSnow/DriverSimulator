This folder contains files that connect CarSim and Simulink; control the movement of vehicle in real-time in CarSim using keyboard interface and DS package. 

The simulink file: CarSimSimulink.slx
S-Function in CMex: key_ctr_CMexS.c

Needs Carsim 2016.1, DS package and VS2012(MEX) + Simulink environment