/*  file name : key_ctr_CMexS.c
%============================================================================================
% The CMex S function can control the carsim live video simulation
 * Used as Matlab S function in Simulink
 * Needs Carsim 2016 later and carsim DS package
 *  Actions:
 *      uparrow---------------forward
 *      downarrow-------------backward
 *      leftarrow-------------turning left
 *      rightarrow------------turning right
 *  Outputs:
 *      throttle
 *      angle
%============================================================================================

%============================================================================================
%   2017-08-17	MH   Created
 *  2017-08-20	MH   Replaced kbhit()/getch() by GetAsyncKeyState();
 *  2017-08-23	MH   Changed speed to throttle to accommdate carsim simulation
 *            	MH   When uparrow/forward or leftarrow/rightarrow released, set throttle 
 *                   or angle to zero
%============================================================================================
*/

#define S_FUNCTION_NAME key_ctr_CMexS
#define S_FUNCTION_LEVEL 2

#define     Reset           0x52    //Press r
#define     Left            0x25   //Press leftarrow
#define     Right           0x27   //Press rightarrow  
#define     Forward         0x26   //Press uparrow
#define     Backward        0x28   //Press downarrow

#define     throt_accel       0.05    //throttle up accel.
#define     spd_decel       -0.2   //throttle down decel.
#define     ang_accel       -5    //turning right accel.
#define     ang_decel       5   //turning left decel.
#define     free_accel      0.01   //accel. when no key pressed
#define     free_decel      -0.05  //decel. when no key pressed
#define     forward_limit   1     //limitation of throttle
#define     backward_limit  0     //limitation of throttle

#include "simstruc.h"

#include <stdio.h>
#include <conio.h>

static void UpdateVehicle(SimStruct *S, int_T tid);

/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 0);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return; /* Parameter mismatch will be reported by Simulink */
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 2);

    if (!ssSetNumInputPorts(S, 0)) return;
    
    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, 2);

    ssSetNumSampleTimes(S, 1);  /* Set number of sampling time */
    ssSetNumRWork(S, 0);    /* Set real work dimension */
    ssSetNumIWork(S, 0);    /* Set integer work dimension */
    ssSetNumPWork(S, 0);    /* Set pointer work dimension */
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);

    /* Take care when specifying exception free code - see sfuntmpl_doc.c */
    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    Specify the sample time as 1.0
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, 1);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);      
}

#define MDL_INITIALIZE_CONDITIONS
/* Function: mdlInitializeConditions ========================================
 * Abstract:
 *    Initialize both discrete states to zero.
 */
static void mdlInitializeConditions(SimStruct *S)
{
    real_T *x0 = ssGetRealDiscStates(S);
    int_T  lp;

    for (lp=0;lp<2;lp++) { 
        *x0++=0.0; 
    }
}


#define MDL_OUTPUTS
/* Function: mdlOutputs ================================================== */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    real_T            *y    = ssGetOutputPortRealSignal(S,0);
    real_T            *x    = ssGetRealDiscStates(S);

    UpdateVehicle(S, tid);    
    printf("Throttle is %f ; Angle is %f\n", x[0], x[1]);
    
    y[0]=x[0];  /* Output x[0] i.e. Throttle */
    y[1]=x[1];  /* Output x[1] i.e. angle */
}



#define MDL_UPDATE
/* Function: mdlUpdate ==================================================*/
static void mdlUpdate(SimStruct *S, int_T tid)
{

}



/*==========================================================================================
% The function can control the self-addition/substraction of two variables (Throttle and angle)
% This function is forked from key_ctr_MatlabS.m in this folder
% Use GetAsyncKeyState() to read keyboard input; it reads the CAPTAL letter of keyboard
% i.e.A,B,C...
% ASCII code refers to Key_board_info.txt.
%==========================================================================================*/

static void UpdateVehicle(SimStruct *S, int_T tid)
{
    real_T *x    = ssGetRealDiscStates(S);
    
    real_T Throttle = x[0];
    real_T angle = x[1];
    
    char key;
    
    /* A key is pressed ============================================================== */
    if (GetAsyncKeyState(Reset)||GetAsyncKeyState(Left)||GetAsyncKeyState(Right)\
            ||GetAsyncKeyState(Forward)||GetAsyncKeyState(Backward))     
    {
        /* Determin operation modes based on keyboard input */
        if (GetAsyncKeyState(Reset))
        {
            key = Reset;
        }
        else if (GetAsyncKeyState(Left))
        {
            key = Left;
        }
        else if (GetAsyncKeyState(Right))
        {
            key = Right;
        }
        else if (GetAsyncKeyState(Forward))
        {
            key = Forward;
        }
        else if (GetAsyncKeyState(Backward))
        {
            key = Backward;
        }   
        
        /* Take actions based on keyboard entry */
        switch (key)
        {
            case Reset:  /* Reset is pressed */
                Throttle = 0;
                angle = 0;
                break;
            /* Determining angle value of the vehicle; [-180 0] turning right, [0 180] turning left. */
            /* Turning left ========================================================= */
            case Left:  /* leftarrow is pressed */
                angle = angle + ang_decel;
                if (angle < -180)
                {
                    angle = angle + 360;
                }
                /* Left and forward */
                if (GetAsyncKeyState(Forward)) /* uparrow is pressed */
                {
                    Throttle = Throttle + throt_accel;
                    if (Throttle > forward_limit)
                    {
                        Throttle = forward_limit;
                    }
                }
                /* Left and backward */
                else if (GetAsyncKeyState(Backward)) /* downarrow is pressed */
                {
                    Throttle = Throttle + spd_decel;
                    if (Throttle < backward_limit)
                    {
                        Throttle = backward_limit;
                    }                            
                }
                /* Left and no up/down */
                else if (Throttle > 0)
                {
                    Throttle = Throttle + free_decel;
                    if (Throttle <= 0.001)
                    {
                        Throttle = 0; 
                    }
                }
                else if  (Throttle < 0)
                {
                    Throttle = Throttle + free_accel;
                    if (Throttle > -0.001)
                    {
                        Throttle = 0;
                    } 
                }
                break;
            /* Turning right ========================================================= */
            case Right: /* rightarrow is pressed */
                angle = angle + ang_accel;
                if (angle > 180)
                {
                    angle = angle - 360;
                }
                /* Determin if up/down is pressed */
                /* Right and forward */
                if (GetAsyncKeyState(Forward)) /* uparrow is pressed */
                {
                    Throttle = Throttle + throt_accel;
                    if (Throttle > forward_limit)
                    {
                        Throttle = forward_limit;
                    }
                }
                /* Left and backward */
                else if (GetAsyncKeyState(Backward)) /* downarrow is pressed */
                {
                    Throttle = Throttle + spd_decel;
                    if (Throttle < backward_limit)
                    {
                        Throttle = backward_limit;
                    }                            
                }
                /* Left and no up/down */
                else if (Throttle > 0)
                {
                    Throttle = Throttle + free_decel;
                    if (Throttle <= 0.001)
                    {
                        Throttle = 0; 
                    }
                }
                else if  (Throttle < 0)
                {
                    Throttle = Throttle + free_accel;
                    if (Throttle > -0.001)
                    {
                        Throttle = 0;
                    } 
                } 
                break;
            /*% Determining Throttle value of the vehicle; Throttle belongs [0 1]. 
            % when upkey is pressed, the Throttle increases up to 1.
            % Acceleration========================================================= */
            case Forward: /* uparrow is pressed */
                Throttle = Throttle + throt_accel;
                if (Throttle > forward_limit)
                {
                    Throttle = forward_limit;
                }
                /* Determin if right/left is pressed */
                /* Right and forward */
                if (GetAsyncKeyState(Right)) /* rightarrow is pressed */
                {
                    angle = angle + ang_accel;
                    if (angle > 180)
                    {
                        angle = angle - 360;
                    }
                }
                /* Left and forward */
                else if (GetAsyncKeyState(Left)) /* leftarrow is pressed */
                {
                    angle = angle + ang_decel;
                    if (angle < -180)
                    {
                        angle = angle + 360;
                    }
                }                
                break;
            /* Deceleration/backward=============================================== */
            case Backward:  /* downarrow is pressed */
                Throttle = Throttle + spd_decel;
                if (Throttle < backward_limit)
                {
                    Throttle = backward_limit;
                }
                /* Determin if right/left is pressed */
                    /* Right and forward */
                if (GetAsyncKeyState(Right)) /* rightarrow is pressed */
                {
                    angle = angle + ang_accel;
                    if (angle > 180)
                    {
                        angle = angle - 360;
                    }
                }
                /* Left and forward */
                else if (GetAsyncKeyState(Left)) /* leftarrow is pressed */
                {
                    angle = angle + ang_decel;
                    if (angle < -180)
                    {
                        angle = angle + 360;
                    }
                } 
                break;
        }   
    }
    /* up/down/left/right is released ============================================================== 
       when up/down is released, the Throttle is set to zero. */  
    if (!GetAsyncKeyState(Forward) && !GetAsyncKeyState(Backward))
    {   
        Throttle = 0;
    }
    /* when right/left is released, the angle is set to zero. */  
    if (!GetAsyncKeyState(Left) && !GetAsyncKeyState(Right))
    {
         angle = 0;     
    }
    
    
    
    
    
    
//     else if (!GetAsyncKeyState(Reset) && !GetAsyncKeyState(Left) && !GetAsyncKeyState(Right)\
//             && !GetAsyncKeyState(Forward) && !GetAsyncKeyState(Backward) && Throttle > 0)
//     {   
// //         speed = speed + free_decel;
// //          if (speed <= 0.001)
// //          {
// //             speed = 0;
// //          }
//         Throttle = 0;
//     }
//     else if (!GetAsyncKeyState(Reset)&&!GetAsyncKeyState(Left)&&!GetAsyncKeyState(Right)\
//             &&!GetAsyncKeyState(Forward)&&!GetAsyncKeyState(Backward) && Throttle < 0)
//     {
//          Throttle = Throttle + free_accel;
//          if (Throttle > -0.001)
//          {
//             Throttle = 0;
//          }     
//     }
    
    x[0] = Throttle;
    x[1] = angle;
}
    


/* Function: mdlTerminate =====================================================
 * Abstract:
 *    No termination needed, but we are required to have this routine.
 */
static void mdlTerminate(SimStruct *S)
{
    UNUSED_ARG(S); /* unused input argument */
}

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
